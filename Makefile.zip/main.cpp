#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL_ttf.h>

// Screen dimensions
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

enum MenuOption {
    CONTINUE_GAME,
    NEW_GAME,
    HIGH_SCORE,
    QUIT,
    NONE
};

bool init(SDL_Window** window, SDL_Surface** screenSurface);
void showInstructions(SDL_Window* window, SDL_Surface* screenSurface);
MenuOption showMenu(SDL_Window* window, SDL_Surface* screenSurface);
void close(SDL_Window* window);














int main(int argc, char* args[]) {
    // Initialize SDL
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "SDL could not initialize! SDL_Error: " << SDL_GetError() << std::endl;
        return -1;
    }

    // Initialize SDL_image
    if (!(IMG_Init(IMG_INIT_PNG) & IMG_INIT_PNG)) {
        std::cerr << "SDL_image could not initialize! SDL_image Error: " << IMG_GetError() << std::endl;
        SDL_Quit();
        return -1;
    }

    // Initialize SDL_ttf
    if (TTF_Init() == -1) {
        std::cerr << "SDL_ttf could not initialize! SDL_ttf Error: " << TTF_GetError() << std::endl;
        IMG_Quit();
        SDL_Quit();
        return -1;
    }

    // Create window
    SDL_Window* window = SDL_CreateWindow("SDL Tutorial",
                                          SDL_WINDOWPOS_UNDEFINED,
                                          SDL_WINDOWPOS_UNDEFINED,
                                          SCREEN_WIDTH,
                                          SCREEN_HEIGHT,
                                          SDL_WINDOW_SHOWN);
    if (window == NULL) {
        std::cerr << "Window could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        TTF_Quit();
        IMG_Quit();
        SDL_Quit();
        return -1;
    }

    // Get window surface
    SDL_Surface* screenSurface = SDL_GetWindowSurface(window);

    // Show instructions page
    showInstructions(window, screenSurface);

    // Show main menu
    MenuOption menuOption = showMenu(window, screenSurface);
    if (menuOption == QUIT) {
        close(window);
        return 0;
    }

    // Load images (assuming images are required after the menu)
    SDL_Surface* image1 = IMG_Load("image.png");
    if (image1 == NULL) {
        std::cerr << "Unable to load image1! SDL_image Error: " << IMG_GetError() << std::endl;
        close(window);
        return -1;
    }

    SDL_Surface* image2 = IMG_Load("image.png");
    if (image2 == NULL) {
        std::cerr << "Unable to load image2! SDL_image Error: " << IMG_GetError() << std::endl;
        SDL_FreeSurface(image1);
        close(window);
        return -1;
    }

    // Apply images
    SDL_Rect dstrect1 = { 0, 0, image1->w, image1->h };
    SDL_BlitSurface(image1, NULL, screenSurface, &dstrect1);

    SDL_Rect dstrect2 = { 320, 240, image2->w, image2->h };
    SDL_BlitSurface(image2, NULL, screenSurface, &dstrect2);

    SDL_UpdateWindowSurface(window);

    // Main loop flag
    bool quit = false;

    // Event handler
    SDL_Event e;

    // While application is running
    while (!quit) {
        // Handle events on the queue
        while (SDL_PollEvent(&e) != 0) {
            // User requests quit
            if (e.type == SDL_QUIT) {
                quit = true;
            }
        }
    }

    // Free loaded images
    SDL_FreeSurface(image1);
    SDL_FreeSurface(image2);

    // Close SDL
    close(window);

    return 0;
}

void showInstructions(SDL_Window* window, SDL_Surface* screenSurface) {
    TTF_Font* font = TTF_OpenFont("resource/pg.ttf", 28);
    if (font == NULL) {
        std::cerr << "Failed to load font! SDL_ttf Error: " << TTF_GetError() << std::endl;
        return;
    }

    SDL_Color textColor = {255, 255, 255};
    SDL_Surface* instructionsSurface = TTF_RenderText_Solid(font, "Press Enter to Continue", textColor);
    if (instructionsSurface == NULL) {
        std::cerr << "Unable to render text surface! SDL_ttf Error: " << TTF_GetError() << std::endl;
        TTF_CloseFont(font);
        return;
    }

    SDL_Rect instructionsRect = { SCREEN_WIDTH / 2 - instructionsSurface->w / 2, SCREEN_HEIGHT / 2 - instructionsSurface->h / 2, instructionsSurface->w, instructionsSurface->h };

    SDL_FillRect(screenSurface, NULL, SDL_MapRGB(screenSurface->format, 0x00, 0x00, 0x00));
    SDL_BlitSurface(instructionsSurface, NULL, screenSurface, &instructionsRect);
    SDL_UpdateWindowSurface(window);

    SDL_FreeSurface(instructionsSurface);
    TTF_CloseFont(font);

    bool continueFlag = false;
    SDL_Event e;
    while (!continueFlag) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                exit(0);
            } else if (e.type == SDL_KEYDOWN && e.key.keysym.sym == SDLK_RETURN) {
                continueFlag = true;
            }
        }
    }
}

MenuOption showMenu(SDL_Window* window, SDL_Surface* screenSurface) {
    TTF_Font* font = TTF_OpenFont("resource/pg.ttf", 28);
    if (font == NULL) {
        std::cerr << "Failed to load font! SDL_ttf Error: " << TTF_GetError() << std::endl;
        return QUIT;
    }

    SDL_Color textColor = {255, 255, 255};

    SDL_Surface* continueSurface = TTF_RenderText_Solid(font, "Continue", textColor);
    SDL_Surface* newGameSurface = TTF_RenderText_Solid(font, "New Game", textColor);
    SDL_Surface* highScoreSurface = TTF_RenderText_Solid(font, "High Score", textColor);
    SDL_Surface* quitSurface = TTF_RenderText_Solid(font, "Quit", textColor);

    if (continueSurface == NULL || newGameSurface == NULL || highScoreSurface == NULL || quitSurface == NULL) {
        std::cerr << "Unable to render text surface! SDL_ttf Error: " << TTF_GetError() << std::endl;
        TTF_CloseFont(font);
        return QUIT;
    }

    SDL_Rect continueRect = { SCREEN_WIDTH / 2 - continueSurface->w / 2, 150, continueSurface->w, continueSurface->h };
    SDL_Rect newGameRect = { SCREEN_WIDTH / 2 - newGameSurface->w / 2, 250, newGameSurface->w, newGameSurface->h };
    SDL_Rect highScoreRect = { SCREEN_WIDTH / 2 - highScoreSurface->w / 2, 350, highScoreSurface->w, highScoreSurface->h };
    SDL_Rect quitRect = { SCREEN_WIDTH / 2 - quitSurface->w / 2, 450, quitSurface->w, quitSurface->h };

    SDL_FillRect(screenSurface, NULL, SDL_MapRGB(screenSurface->format, 0x00, 0x00, 0x00));

    SDL_BlitSurface(continueSurface, NULL, screenSurface, &continueRect);
    SDL_BlitSurface(newGameSurface, NULL, screenSurface, &newGameRect);
    SDL_BlitSurface(highScoreSurface, NULL, screenSurface, &highScoreRect);
    SDL_BlitSurface(quitSurface, NULL, screenSurface, &quitRect);

    SDL_UpdateWindowSurface(window);

    SDL_FreeSurface(continueSurface);
    SDL_FreeSurface(newGameSurface);
    SDL_FreeSurface(highScoreSurface);
    SDL_FreeSurface(quitSurface);
    TTF_CloseFont(font);

    bool quit = false;
    SDL_Event e;
    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                return QUIT;
            } else if (e.type == SDL_MOUSEBUTTONDOWN) {
                int x, y;
                SDL_GetMouseState(&x, &y);
                if (x >= continueRect.x && x <= continueRect.x + continueRect.w &&
                    y >= continueRect.y && y <= continueRect.y + continueRect.h) {
                    return CONTINUE_GAME;
                }
                if (x >= newGameRect.x && x <= newGameRect.x + newGameRect.w &&
                    y >= newGameRect.y && y <= newGameRect.y + newGameRect.h) {
                    return NEW_GAME;
                }
                if (x >= highScoreRect.x && x <= highScoreRect.x + highScoreRect.w &&
                    y >= highScoreRect.y && y <= highScoreRect.y + highScoreRect.h) {
                    return HIGH_SCORE;
                }
                if (x >= quitRect.x && x <= quitRect.x + quitRect.w &&
                    y >= quitRect.y && y <= quitRect.y + quitRect.h) {
                    return QUIT;
                }
            }
        }
    }
    return NONE;
}

void close(SDL_Window* window) {
    // Destroy window
    SDL_DestroyWindow(window);

    // Quit SDL_image
    IMG_Quit();

    // Quit SDL_ttf
    TTF_Quit();

    // Quit SDL subsystems
    SDL_Quit();
}
